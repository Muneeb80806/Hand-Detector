# Hand-Tracking
Hand Tracking module with all fingers using Python

Mediapipe Solutions: https://google.github.io/mediapipe/solutions/hands
